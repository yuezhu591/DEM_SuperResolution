from SR_DEM_code.model.RCAN import RCAN
from os import listdir
import numpy as np
import torch
from torch.utils.data import Dataset, DataLoader
from DEM_SuperResolution import pytorch_ssim
from torch.optim import lr_scheduler
import torch.optim as optim
from torch import nn
import argparse
from math import log10
import pandas as pd
import os


class SrDEM_Train_Dataset_V(Dataset):
    def __init__(self, lr_dem_path, hr_dem_path, crop_size, num_samples):
        self.lr_dem_path = lr_dem_path
        self.hr_dem_path = hr_dem_path

        self.lr_dem_filenames = sorted([x for x in listdir(lr_dem_path) if x.endswith('.npy')])
        self.hr_dem_filenames = sorted([x for x in listdir(hr_dem_path) if x.endswith('.npy')])

        self.crop_size = crop_size
        self.num_samples = num_samples

    def __len__(self):
        return self.num_samples

    def __getitem__(self, idx):
        lr_dem = np.load(self.lr_dem_path + self.lr_dem_filenames[idx])
        hr_dem = np.load(self.hr_dem_path + self.hr_dem_filenames[idx])

        lr_dem_tensor = torch.from_numpy(lr_dem).unsqueeze(0)
        hr_dem_tensor = torch.from_numpy(hr_dem).unsqueeze(0)

        return lr_dem_tensor, hr_dem_tensor


def train_net(net, device, model_name, epochs=5, batch_size=5, lr = 8e-5, bands = 4,
              save_cp=True, save_csv=True):

    train_lr_DEM = '../data/resample/train/DEM_30m_crop/'
    train_hr_DEM = '../data/resample/train/DEM_10m_crop/'
    train_set = SrDEM_Train_Dataset_V(train_lr_DEM, train_hr_DEM, crop_size=80, num_samples=1000)
    train_loader = DataLoader(train_set, batch_size=batch_size, shuffle=True)

    valid_lr_DEM = '../data/resample/valid/DEM_30m_crop/'
    valid_hr_DEM = '../data/resample/valid/DEM_10m_crop/'
    valid_set = SrDEM_Train_Dataset_V(valid_lr_DEM, valid_hr_DEM, crop_size=80, num_samples=80)
    valid_loader = DataLoader(valid_set, batch_size=batch_size, shuffle=False)

    test_lr_DEM = '../data/resample/test/DEM_30m_crop/'
    test_hr_DEM = '../data/resample/test/DEM_10m_crop/'
    test_set = SrDEM_Train_Dataset_V(test_lr_DEM, test_hr_DEM, crop_size=80, num_samples=50)
    test_loader = DataLoader(test_set, batch_size=batch_size, shuffle=False)

    optimizer = optim.Adam(filter(lambda p: p.requires_grad, net.parameters()), lr=lr, betas=(0.9, 0.999))
    lr_scheduler_factor = 0.8
    scheduler = lr_scheduler.ReduceLROnPlateau(optimizer, mode='max', factor=lr_scheduler_factor,
                                               patience=args.patience,
                                               verbose=True)
    criterion = nn.L1Loss()
    criterion.to(device)


    # -------------------------------------- Train ----------------------------------------------
    df = pd.DataFrame()

    for epoch in range(epochs):
        train_record = {'loss': 0, 'ssim': 0, 'psnr': 0}

        net.train()

        for i, (lr_dem, hr_dem) in enumerate(train_loader):
            lr_dem = lr_dem.to(device, dtype=torch.float)
            hr_dem = hr_dem.to(device, dtype=torch.float)
            fake_hr_dem = net(lr_dem)

            optimizer.zero_grad()

            image_loss = criterion(fake_hr_dem, hr_dem)
            image_loss.backward()
            optimizer.step()

            ssim = pytorch_ssim.ssim(fake_hr_dem, hr_dem).item()
            mse = ((fake_hr_dem - hr_dem) ** 2).data.mean()
            psnr = 10 * log10((hr_dem.max() ** 2) / mse)

            train_record['loss'] += image_loss.item()
            train_record['ssim'] += ssim
            train_record['psnr'] += psnr

            if i % 10 == 0:
                print('Epoch[{}/{}]: '.format(epoch + 1, epochs),
                      'loss:', image_loss.item(), 'ssim:', ssim, 'psnr:', psnr)

        train_record['loss'] = train_record['loss'] / len(train_loader)
        train_record['ssim'] = train_record['ssim'] / len(train_loader)
        train_record['psnr'] = train_record['psnr'] / len(train_loader)

        print('Train: Epoch[{}/{}]: '.format(epoch + 1, epochs), train_record)
        print('---------------------------------------------------------------------------------------')

    # -------------------------------------- Valid ----------------------------------------------

        net.eval()
        val_record = {'val_loss': 0, 'val_ssim': 0, 'val_psnr': 0}
        with torch.no_grad():

            for i, (val_lr_dem, val_hr_dem) in enumerate(valid_loader):
                lr_dem = val_lr_dem.to(device, dtype=torch.float)
                hr_dem = val_hr_dem.to(device, dtype=torch.float)
                fake_hr_dem = net(lr_dem)

                val_loss = criterion(fake_hr_dem, hr_dem)

                val_ssim = pytorch_ssim.ssim(fake_hr_dem, hr_dem).item()
                val_mse = ((fake_hr_dem - hr_dem) ** 2).data.mean()
                val_psnr = 10 * log10((hr_dem.max() ** 2) / val_mse)

                val_record['val_loss'] += val_loss.item()
                val_record['val_ssim'] += val_ssim
                val_record['val_psnr'] += val_psnr

            val_record['val_ssim'] = val_record['val_ssim'] / len(valid_loader)
            val_record['val_psnr'] = val_record['val_psnr'] / len(valid_loader)
            val_record['val_loss'] = val_record['val_loss'] / len(valid_loader)

            print('Validation: Epoch[{}/{}]'.format(epoch + 1, epochs), val_record)
            print('---------------------------------------------------------------------------------------')


    # -------------------------------------- test ----------------------------------------------

        test_record = {'test_loss': 0, 'test_ssim': 0, 'test_psnr': 0}
        with torch.no_grad():
            for i, (test_lr_dem, test_hr_dem) in enumerate(test_loader):
                lr_dem = test_lr_dem.to(device, dtype=torch.float)
                hr_dem = test_hr_dem.to(device, dtype=torch.float)
                fake_hr_dem = net(lr_dem)

                test_loss = criterion(fake_hr_dem, hr_dem)

                test_ssim = pytorch_ssim.ssim(fake_hr_dem, hr_dem).item()
                test_mse = ((fake_hr_dem - hr_dem) ** 2).data.mean()
                test_psnr = 10 * log10((hr_dem.max() ** 2) / test_mse)

                test_record['test_loss'] += test_loss.item()
                test_record['test_ssim'] += test_ssim
                test_record['test_psnr'] += test_psnr

            test_record['test_ssim'] = test_record['test_ssim'] / len(test_loader)
            test_record['test_psnr'] = test_record['test_psnr'] / len(test_loader)
            test_record['test_loss'] = test_record['test_loss'] / len(test_loader)

            print('Test: Epoch[{}/{}]'.format(epoch + 1, epochs), test_record)
            print('---------------------------------------------------------------------------------------')

        scheduler.step(val_loss)

        # ------------------------------------------------ save model -----------------------------------------------
        if save_cp:
            dir_checkpoint = '../ckpts/{}_ckpts/hr_sr_{}b/'.format(model_name, bands)
            os.makedirs(dir_checkpoint, exist_ok=True)
            torch.save(net.state_dict(), dir_checkpoint + '{}_epoch_{}.pth'.format(model_name, epoch))

        if save_csv:
            train_record.update(val_record)
            train_record.update(test_record)
            record_df = pd.DataFrame(train_record, index=[epoch])
            df = df.append(record_df)

            dir_csv = '../record'
            os.makedirs(dir_csv, exist_ok=True)
            df.to_csv('{}/{}_record_band{}_bs{}.csv'.format(dir_csv,model_name, bands, batch_size))

    print('----------------------------------- {} completed! -----------------------------------'.format(model_name))


def get_args():
    parser = argparse.ArgumentParser(description='Train RCAN Models', formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    parser.add_argument('-u', '--upscale_factor', default=3, type=int, choices=[2, 3, 4], help='super resolution upscale factor', dest='upscale_factor')
    parser.add_argument('--num_epochs', default=201, type=int, help='train epoch number', dest='epochs')  # 100
    parser.add_argument('--bands_n', default=1, type=int, help='number of bands', dest='bands_n')  # 100
    parser.add_argument('--patience', default=50, type=int, help='learning rate decrease patience', dest='patience')
    parser.add_argument('-b', '--batch-size', metavar='B', type=int, nargs='?', default=8, help='Batch size', dest='batchsize')
    return parser.parse_args()


if __name__ == '__main__':
    args = get_args()
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(device)

    net = RCAN(num_in_ch=args.bands_n, num_out_ch=args.bands_n, num_feat=64, num_group=10, num_block=16,
               squeeze_factor=16, upscale=args.upscale_factor, res_scale=1)
    net.to(device)

    print('generator parameters:', sum(param.numel() for param in net.parameters()))
    print('number of bands: ', args.bands_n)
    print('patience: ', args.patience)
    print('batch size: ', args.batchsize)

    train_net(net, device, model_name='RCAN_v', epochs=args.epochs,
              batch_size=args.batchsize, lr = 0.0001, bands = args.bands_n,
              save_cp=True, save_csv=True)



