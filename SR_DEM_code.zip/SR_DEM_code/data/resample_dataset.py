import numpy as np
import os

np.random.seed(2)

def makedir(new_dir):
    if not os.path.exists(new_dir):
        os.makedirs(new_dir)

def get_net_points(img, overlap = 30, img_size=150):
    cen_x = img_size // 2
    cen_y = img_size // 2
    corp_x_n = (img.shape[0] - img_size) // (img_size - overlap) + 1
    corp_y_n = (img.shape[1] - img_size) // (img_size - overlap) + 1
    x_list = []
    y_list = []
    lr_x_list = []
    lr_y_list = []
    for i in range(corp_x_n):
        for j in range(corp_y_n):
            x = cen_x + i * (img_size - overlap)
            y = cen_y + j * (img_size - overlap)
            x_list.append(x)
            y_list.append(y)
            lr_x_list.append(x//3)
            lr_y_list.append(y//3)
    print('number of sub-samples per img: ', len(x_list))

    return zip(x_list, y_list), zip(lr_x_list, lr_y_list)


def get_cropped_img(x_y_list, img, img_size = 150):
    cropped_imgs = []
    for x, y in x_y_list:
        if img.ndim == 3:
            temp = img[x-img_size//2: x+ img_size//2, y-img_size//2: y+ img_size//2, :]
        else:
            temp = img[x - img_size // 2: x + img_size // 2, y - img_size // 2: y + img_size // 2]
        cropped_imgs.append(temp)
    print(len(cropped_imgs))

    return cropped_imgs


if __name__ == '__main__':

    mode = 'train'
    # mode = 'valid'
    # mode = 'test'

    hr_dir = '../data/ori_data/{}/DEM_10m/'.format(mode)
    lr_dir = '../data/ori_data/{}/DEM_30m/'.format(mode)
    hr_ms_dir = '../data/ori_data/{}/MS_10m/'.format(mode)
    hr_path = [os.path.join(hr_dir, x) for x in os.listdir(hr_dir) if x.endswith('.npy')]
    lr_path = [os.path.join(lr_dir, x) for x in os.listdir(lr_dir) if x.endswith('.npy')]
    hr_ms_path = [os.path.join(hr_ms_dir, x) for x in os.listdir(hr_ms_dir) if x.endswith('.npy')]

    for i in range(len(hr_path)):

        hr_dem = np.load(hr_path[i])
        lr_dem = np.load(lr_path[i])
        hr_ms = np.load(hr_ms_path[i])

        img_h = np.min(np.array([hr_dem.shape[0]//3,lr_dem.shape[0],hr_ms.shape[0]//3]))
        img_w = np.min(np.array([hr_dem.shape[1]//3,lr_dem.shape[1], hr_ms.shape[1]//3]))
        print(img_h, img_w)

        hr_dem = hr_dem[:img_h*3, :img_w*3]
        lr_dem = lr_dem[:img_h, :img_w]
        hr_ms = hr_ms[:img_h*3, :img_w*3, :]
        print('hr_dem shape: ', hr_dem.shape)
        print('lr_dem shape: ', lr_dem.shape)
        print('hr_ms shape: ', hr_ms.shape)

        hr_crop_size = 240
        hr_overlap_size = 10
        upscale_factor = 3

        hr_x_y, lr_x_y = get_net_points(hr_dem, hr_overlap_size, hr_crop_size)
        cropped_lr_dem = get_cropped_img(lr_x_y, lr_dem, hr_crop_size // upscale_factor)
        cropped_hr_dem = get_cropped_img(hr_x_y, hr_dem, hr_crop_size)

        hr_x_y,_ = get_net_points(hr_dem, hr_overlap_size, hr_crop_size)
        cropped_hr_ms = get_cropped_img(hr_x_y, hr_ms, hr_crop_size)

        resample_hr_dem_path = '../data/resample/{}/DEM_10m_crop/'.format(mode)
        resample_lr_dem_path = '../data/resample/{}/DEM_30m_crop/'.format(mode)
        resample_hr_ms_path = '../data/resample/{}/MS_10m_crop/'.format(mode)
        os.makedirs(resample_hr_dem_path, exist_ok=True)
        os.makedirs(resample_lr_dem_path, exist_ok=True)
        os.makedirs(resample_hr_ms_path, exist_ok=True)

        for k, sub_lr_dem in enumerate(cropped_lr_dem):
            np.save(resample_lr_dem_path + '{}.npy'.format(i * len(cropped_lr_dem) + k), sub_lr_dem)
            print('cropped_lr_dem: ',i * len(cropped_lr_dem) + k)

        for q, sub_hr_dem in enumerate(cropped_hr_dem):
            np.save(resample_hr_dem_path + '{}.npy'.format(i * len(cropped_hr_dem) + q), sub_hr_dem)
            print('cropped_hr_dem: ',i * len(cropped_hr_dem) + q)

        for p, sub_hr_ms in enumerate(cropped_hr_ms):
            np.save(resample_hr_ms_path + '{}.npy'.format(i * len(cropped_hr_ms) + p), sub_hr_ms)
            print('cropped_hr_ms: ',i * len(cropped_hr_ms) + p)


        print('-------------------------------------------')
